package br.com.indtexbr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoNormasApplicationTests {

	@Test
	void contextLoads() {
	}

}
